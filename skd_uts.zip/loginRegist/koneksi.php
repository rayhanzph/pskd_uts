<?php
$db = mysqli_connect("localhost","root","", "skd_prak_uts");
